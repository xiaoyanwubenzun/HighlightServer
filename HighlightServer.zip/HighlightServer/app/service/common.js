const Service = require('egg').Service;
const svgCaptcha = require("svg-captcha");
class CommonService extends Service {
	async svgVerifyImg() {
		let result = {
			data: {},
			code: 200,
			message: "success",
		}; 
		// const { ctx } = this;
		const captcha = svgCaptcha.create({
			size: 4,
			fontSize: 50,
			width: 100,
			height: 40,
			bacground: "#48D1CC"
		});
		this.ctx.session.svgtext = captcha.text; //缓存验证码中的文字
		result.data.img = captcha.data;
		return result;
	}
}
module.exports = CommonService;