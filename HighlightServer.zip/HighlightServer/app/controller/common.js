"use strict";
const Controller = require("egg").Controller;

class commonController extends Controller { 
	async svgVerifyImg() {
		// let result = {
		// 	data: {},
		// 	code: 200,
		// 	message: "success",
		// }; 
		// const { ctx } = this;
		// const captcha = svgCaptcha.create({
		// 	size: 4,
		// 	fontSize: 50,
		// 	width: 100,
		// 	height: 40,
		// 	bacground: "#48D1CC"
		// });
		// this.ctx.session.svgtext = captcha.text; //缓存验证码中的文字
		// result.data.img = captcha.data;
		// ctx.body = result;

		const { ctx } = this;
		const result = await ctx.service.common.svgVerifyImg();
		ctx.body = result;
	}
}
module.exports = commonController;