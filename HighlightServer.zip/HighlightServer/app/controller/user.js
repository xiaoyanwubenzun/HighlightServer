"use strict";
const Controller = require("egg").Controller;
class UserController extends Controller {
	async changeusermessage() {
		const { ctx } = this;
		const obj = ctx.request.body;
		const result = await ctx.service.user.changeusermessage(obj);
		ctx.body = result;
	}
	async getuserpaiming() {
		const { ctx } = this;
		const result = await ctx.service.user.getuserpaiming();
		ctx.body = result;
	}
	async searchuserbestvideo() {
		const { ctx } = this;
		const obj = ctx.request.query;
		const result = await ctx.service.user.searchuserbestvideo(obj);
		ctx.body = result;
	}
	async login() {
		const { ctx } = this;
		const obj = ctx.request.body;
		const result = await ctx.service.user.login(obj);
		ctx.body = result;
	}
	async logout() {
		let result = { data: {}, code: 200, message: "退出成功", }; 
		const { ctx } = this;
		ctx.body = result;
	}
	//注册
	async zhuce() {
		const { ctx } = this;
		const obj = ctx.request.body;
		const result = await ctx.service.user.zhuce(obj);
		ctx.body = result;
	}
	//忘记密码
	async forgetpass() {
		const { ctx } = this;
		const obj = ctx.request.body;
		const result = await ctx.service.user.forgetpass(obj);
		ctx.body = result;
	}
	async getusermessage() {
		const { ctx } = this;
		const token = ctx.request.header["highlight-token"]
		const decoded = ctx.app.jwt.decode(token);
		const result = await ctx.service.user.getusermessage(decoded.username);
		ctx.body = result;
	}
}
module.exports = UserController;