"use strict";

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
	const { router, controller, middleware } = app;
	router.get("/", middleware.jwtVerify(app.config.jwt), controller.home.index);
	router.get("/common/svgimg", middleware.jwtVerify(app.config.jwt), controller.common.coder);
	// router.get("/islogin", controller.user.islogin);
	router.post("/user/logout", middleware.jwtVerify(app.config.jwt), controller.user.logout);
	router.post("/user/login", middleware.jwtVerify(app.config.jwt), controller.user.login);
	// router.post("/user/getusermessage", middleware.jwtVerify(app.config.jwt), controller.user.getusermessage);

	router.get("/user/getuserpaiming", middleware.jwtVerify(app.config.jwt), controller.user.getuserpaiming);
	router.get("/user/searchuserbestvideo", middleware.jwtVerify(app.config.jwt), controller.user.searchuserbestvideo);
	router.post("/user/zhuce", middleware.jwtVerify(app.config.jwt), controller.user.zhuce);
	router.post("/user/forgetpass", middleware.jwtVerify(app.config.jwt), controller.user.forgetpass);
	router.post("/user/changeusermessage", middleware.jwtVerify(app.config.jwt), controller.user.changeusermessage);

	router.post("/upload/uploadimg", middleware.jwtVerify(app.config.jwt), controller.upload.uploadimg);
	router.post("/upload/uploadvideo", middleware.jwtVerify(app.config.jwt), controller.upload.uploadvideo);
	
	//控制层js文件名对应数据库表名，方法名对应增删改查
	router.post("/video/search", middleware.jwtVerify(app.config.jwt), controller.video.search);
	router.get("/video/myhightlightsearch", middleware.jwtVerify(app.config.jwt), controller.video.myhightlightsearch);
	router.get("/video/searchbestvideo", middleware.jwtVerify(app.config.jwt), controller.video.searchbestvideo);
	router.get("/video/getvideomessage", middleware.jwtVerify(app.config.jwt), controller.video.getvideomessage);
	router.get("/video/addlikecount", middleware.jwtVerify(app.config.jwt), controller.video.addlikecount);
	router.post("/video/uploadhightlight", middleware.jwtVerify(app.config.jwt), controller.video.uploadhightlight);


	router.get("/comment/addcomment", middleware.jwtVerify(app.config.jwt), controller.comment.addcomment);
	router.get("/comment/reloadcomment", middleware.jwtVerify(app.config.jwt), controller.comment.reloadcomment);
};