"use strict";

// 定制白名单
const whiteList = [ "/user/login","/common/svgimg"];

module.exports = (options) => {
	return async function (ctx, next) {
        if(!whiteList.some(item=>item==ctx.request.url)){//判断接口路径是否在白名单
			let token = ctx.request.header["highlight-token"]//拿到token
            if(token){//如果token存在
				// let decoded = ctx.app.jwt.decode(token)
				// console.log(decoded);
				let verify = ctx.app.jwt.verify(token, options.secret, (error, success) => { 
					// error是token失效或无效时返回的参数
					if (error) {
						if (error.name == "TokenExpiredError") {//token过期
							// let str = {
							// 	iat: 1,
							// 	exp: 0,
							// 	msg: "token过期"
							// }
							// return str;
							ctx.body = {
								data: {},
								code: 50014,
								message: "token过期"
							};
						} else if (error.name == "JsonWebTokenError") {//无效的token
							ctx.body = {
								data: {},
								code: 50009,
								message: "token无效"
							};
						}
					}
					else { 
						return success
					}
				})
				if (verify) {
					if (verify.iat < verify.exp) {
						// console.log(verify);
						await next();
					}
					else { 
						// console.log(verify);
						return
					}
				}
				else { 
					return
				}
				// if (verify.iat < verify.exp) {
				// 	await next()
				// }
				// else { 

				// }
				// if (err.name == "TokenExpiredError") {//token过期
				// 	// let str = {
				// 	// 	iat: 1,
				// 	// 	exp: 0,
				// 	// 	msg: "token过期"
				// 	// }
				// 	// return str;
				// 	ctx.body = {
				// 		data: {},
				// 		code: 50014,
				// 		message: "token过期"
				// 	};
				// } else if (err.name == "JsonWebTokenError") {//无效的token
				// 	ctx.body = {
				// 		data: {},
				// 		code: 50009,
				// 		message: "token无效"
				// 	};
				// }
				// console.log(verify);
                // if(decoded&&decoded.openid){
                //     ctx.body = {
                //         code: 0,
                //         openid: decoded.openid
                //     }
                // }else{
                //     ctx.openid=decoded.openid//把openid存在ctx上，方便后续操作。
                //     await next()
				// }
				// if (verify.iat < verify.exp) {
				// 	//开始时间小于结束时间，代表token还有效
				// 	await next()
				// } else {
				// 	return false
				// }
				// try {
				// 	ctx.app.jwt.verify(token, options.secret); // 验证token 
				// 	await next();
				// } catch (error) {
				// 	console.log(error);
				// 	ctx.body = {
				// 		data: { },
				// 		massage: "token已过期，请重新登录",
				// 		code: 50014,
				// 	}
				// 	return;
				// }
            }else{
				ctx.body = {
					data: {},
					code: 50008,
					message: "未设置token"
				};
				return;
            }
        }else{
            await next()
        }
    }
}